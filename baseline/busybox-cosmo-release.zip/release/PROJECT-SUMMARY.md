# busybox × Cosmopolitan 跨平台单二进制项目总结

**日期**：2026-09-03 ｜ **基座**：busybox 1.38.0 + cosmo master（定制工具链）｜ **目标**：单一 APE 在 Windows/Linux/macOS 原生运行，全平台功能可用

## 一、选型历程（四路线对比）

| 路线 | 结论 | 依据 |
|---|---|---|
| A. busybox + cosmocc | ✅ **采用** | 实证跑通；有 shell(ash)；补丁可控 |
| B. toybox + superconfigure | 备选 | 配方现成但无 shell、功能差一档 |
| C. busybox-w32（MinGW 原生） | 参考 | fork 用 2500 行状态序列化最脆弱(issue #604 未修)；其避坑清单全库借鉴 |
| D. armybox(Rust) + cargo_cosmo | 观察 | armybox mac 编译失败；cargo_cosmo 1 周龄；常量 shim 只覆盖 std 路径 |

选型文档：早期调研报告在会话记录与记忆；busybox-w32 参考源码在 `refs/busybox-w32`。

## 二、最终架构

```
busybox-1.38.0 (裁剪配置 ~320 applet, STANDALONE+PREFER_APPLETS)
   + busybox 适配补丁(83 文件)
   + cosmo master libc(定制: /dev/zero, mac 路径, QuickEdit 鼠标 + 64K 布局)
   + apelink(定制: aarch64 嵌入 64K 对齐)
   = 单一 APE / fat 双架构
```

**工具链配方**（`patches/cosmo-toolchain/README.md`）：cosmocc 3.9.2 编译驱动 + master 头（isystem+integral+cosmocc.h.txt）+ master 库（cosmopolitan.a，含补丁）+ ape 全套部件——**头+库+链接件必须全套一致**（单文件替换必遇 EEXIST 类常量语义错）。

## 三、修复全景

### 1. busybox 适配（Windows 为主，全平台生效）

| # | 问题 | 根因 | 修复 |
|---|---|---|---|
| 1 | wget https 报 Socket error | openssl helper `child_failed` 依赖 vfork 共享内存，cosmo 非共享 | `__COSMOPOLITAN__` 下走 internal TLS |
| 2 | ash 内 applet not found | Windows 无符号链接 farm + `/proc/self/exe` 不可 exec | STANDALONE+PREFER_APPLETS 配置 + `get_busybox_exec_path()` 运行时解析 |
| 3 | ash 管道 exec 错乱 | vfork-nt 与 ash 交互缺陷 | cosmo 下 vforkexec→fork |
| 4 | tar czf 失败 | 压缩子进程 `execlp("gzip")` PATH 找不到 | execv 自身 gzip applet |
| 5 | ps 不可用 | cosmo 无 /proc | Windows=Toolhelp 枚举、Linux=/proc、mac=透传 /bin/ps |
| 6 | ls 中文变 `?` | LAST_SUPPORTED_WCHAR=767 且 WIDE 关（宽字符转 `?`） | 40959 + WIDE_WCHARS=y（顺带修中文输入回显） |
| 7 | （杂项） | extern const 平台化常量、mkfifo(3)、UAPI 头缺失 | 编译期修复/裁剪/stub（agent 早期 89 文件） |

### 2. cosmo 定制补丁（工具链层，5 个已落地）

| 补丁 | 效果 | 验证 |
|---|---|---|
| /dev/zero Windows 虚拟（kFdDevZero，13 文件） | dd/读零可用 | Windows 46/46 |
| mac 自身路径（KERN_PROCARGS2） | mac 嵌套 exec 根治 | mac 清 PATH 全过 |
| QuickEdit 鼠标保留（tcsetattr） | busybox sh 内鼠标选择/粘贴 | Windows 待最终（补丁已备） |
| 64K 布局（链接页 64K） | 64K 页内核 ELF 可用 | 鲲鹏 UOS 45/46 |

### 3. 64K 页 loader 工程（三层修复 + 关键发现）

| # | 缺陷 | 修复 |
|---|---|---|
| 1 | ape loader 自身 64K 不同余（加载即崩） | `ape/BUILD.mk` max-page-size→64K |
| 2 | apelink 嵌入 16K 假设（绝对化 phdr 被 loader 拒） | `tool/build/apelink.c` aarch64 pagesz→64K |
| 3 | **binfmt 无 P flag → exec argv[0] 剥 → 嵌套 exec 全挂** | 注册 `FP`（**<5.12 内核同样需要**——apeinstall 只在 5.12+ 用 P 是上游缺陷，issue 草稿已备） |

loader 必须装 `/usr/bin/ape`（cosmo OldApeLoader 检测名单）。

## 四、验证矩阵（全实机）

| 平台 | 用法 | smoke | deep | 备注 |
|---|---|---|---|---|
| Windows x86_64 | busybox.com | **46/46** | — | ps/dev/zero/Unicode/鼠标全绿 |
| Linux x86_64 | APE 直跑 | 45/46 | 31/31 | podman |
| Linux aarch64 64K 页 | ELF 直跑 / APE+loader+FP | 45/46 | 31/31 | 双路径同功能（鲲鹏 UOS 实机） |
| macOS | APE | 45/46 | — | 嵌套 exec 根治；[win] 项为平台预期 |
| fat.ape | 4K/16K 页系统 | — | — | arm64 载荷待 4K 页机器最终确认 |

[win] 项=cosmo Windows 专属路径映射（/c/Windows），其他平台预期 FAIL。

## 五、发布物

**`cosmo-dist/busybox-cosmo-release.zip`**（release/，14 文件）：

| 文件 | 用途 |
|---|---|
| busybox.com / busybox-x86_64.ape | Windows/Linux/macOS x86_64（md5 4094c91a） |
| busybox-arm64.ape | aarch64 APE（4K/16K 页，经 loader 跑） |
| busybox-arm64-linux-elf / -linux | aarch64 ELF（64K 页直跑 / stripped） |
| busybox-fat.ape | 双架构 fat |
| ape-loader-aarch64 / x86_64 | ape loader（64K 修复版） |
| smoke.sh / deep-test.sh / smoke-test.bat / README.txt / md5sums.txt | 测试与文档 |

## 六、部署指南（要点）

1. **pristine 规则**：APE 首跑会"同化"改写成平台格式——zip 母本分发，每平台各拷原件首跑；测试用副本。
2. **Windows**：文件名须含 busybox（busybox.exe/com）；建议 Windows Terminal（中文/选择/粘贴最优）。
3. **64K 页 Linux**：见 release/README.txt——loader 装 /usr/bin/ape + `FP` 注册，或直接 ELF。
4. **普通 Linux/mac**：APE 直接跑（无 binfmt 时走 shell 前缀自同化）。

## 七、已知限制与遗留

| 项 | 状态 |
|---|---|
| fat 在 4K/16K 页 aarch64 实机 | 待有机器时确认 |
| QuickEdit 鼠标（tcsetattr 补丁） | 补丁已备，待工具链重打后 Windows 验证 |
| mkfifo/mknod（cosmo 缺 mknodat） | cosmo 上游缺口 |
| nproc（sched_getaffinity） | cosmo 上游缺口 |
| cosmo 上游 issue：#1174（Windows fork accept socket）、apeinstall P flag（草稿已备） | 待提交 |

## 八、经验教训（排查方法论）

1. **vfork 共享内存模式**（child_failed/vfork_exec_errno）在 cosmo Windows 全失效——busybox-w32 全绕 fork 是正确路线
2. **头+库+链接件全套一致**才能替换工具链；单件替换必遇符号/常量错
3. **mac 测试失真**：`__program_executable_name` 退化为 argv0/`$_`（污染）、PATH 真工具掩盖——以 Windows/Linux 实机为准
4. **测试纪律**：容器勿直接挂载分发目录运行（同化改写源文件）；发布件绝不本机直跑
5. 64K 页问题全链路：链接布局→apelink 嵌入→loader 加载→binfmt argv，每一层都有独立缺陷
6. P flag（preserve-argv0）是 binfmt 老特性，<5.12 内核同样生效——cosmo 5.12 边界只是 auxv 通知版本

## 九、关键位置索引

- 完整 busybox 补丁：`patches/busybox-1.38.0-cosmo-full.patch`（83 文件，patch -p1 可应用）
- cosmo 定制补丁快照：`patches/cosmo-toolchain/`（含构建配方、issue 草稿）
- 构建脚本：`build-ape.sh`（双架构）、`build-release.sh`（发布包）
- 测试：`smoke.sh`（46 项）、`deep-test.sh`（31 项）
- 文档：`README.md`（工作区）、`BUILD.md`（构建）
